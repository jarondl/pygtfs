#!/usr/bin/python
# $Id: $

# pylint: disable=C,bare-except

import calendar
import datetime
import os
import subprocess


INHIBIT_FILE = '<%= @inhibit_file_path %>'
PUSH_METRIC_BIN = '<%= @push_metrics_path %>'
METRICS = {'inhibited_since': "", 'inhibited_until': ""}


def InhibitCheck(fname):
  """Determine the time when Puppet was first inhibited and the time Pupppet
  should no longer be inhibited.

  Args:
    fname: File name that is generated when Puppet becomes inhibited.
  """

  METRICS['inhibited_since'] = os.stat(fname).st_ctime

  with open(fname, 'r') as f:
    content = f.read()
    try:
      content = (content.strip()).translate(None, '/-.')
      # Manually convert to PST so the unix timestamp will display the correct
      # time or close to the correct time for inhibit end (midnight)
      # This is a rough number, and can be an hour off if DST is in effect
      time = datetime.datetime.strptime(content + '08UTC', "%Y%m%d%H%Z")
      METRICS['inhibited_until'] = calendar.timegm(time.timetuple())
    except:
      # If a date isn't specified default export of 30 days from now.
      METRICS['inhibited_until'] = METRICS['inhibited_since'] + (30 * 86400)

  return METRICS


def PushMetrics():
  """Send Puppet Inhibit METRICS to collectd."""
  if os.path.exists(PUSH_METRIC_BIN):
    if os.path.exists(INHIBIT_FILE):
      PUSH_METRICS = InhibitCheck(INHIBIT_FILE)
      for key, value in PUSH_METRICS.iteritems():
        subprocess.call([PUSH_METRIC_BIN, '--metric',
                         'timestamp_in_secs','--source', 'puppet_inhibited',
                         '--value', str(value), '--label', key,
                         '--logtostderr'])
    else:
      for key, _ in METRICS.iteritems():
        subprocess.call([PUSH_METRIC_BIN, '--metric',
                         'timestamp_in_secs','--source', 'puppet_inhibited',
                         '--value', '0', '--label', key,
                         '--logtostderr'])


def main():
  PushMetrics()

if __name__ == '__main__':
  main()
