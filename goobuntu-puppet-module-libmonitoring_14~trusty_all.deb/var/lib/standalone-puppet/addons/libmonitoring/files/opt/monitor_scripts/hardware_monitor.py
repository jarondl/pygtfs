#!/usr/bin/python
# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/hardware_monitor.py#3 $

"""A monitor util for reporting Hardware status on DELL class Servers."""

import os
import subprocess
import omsa


def PushMetrics(m_list):
  """Pushes metrics to Murdockd daemon to send metrics to Monarch.

  Args:
    m_list: dictionary of metric fields.
  """
  if not m_list:
    return
  pm = 'push_metrics'
  if os.name == 'posix':
    pm = '/usr/local/bin/' + pm
  for m in m_list:
    type_instance = m.get('type_instance', '')
    plugin_instance = m.get('plugin_instance', '')
    m_type = m.get('type')
    m_value = str(m.get('value'))
    p_args = [pm, '--metric', m_type, '--source', 'omsa',
              '--source_action', plugin_instance, '--label', type_instance,
              '--value', m_value, '--stderrthreshold', 'WARNING']
    subprocess.call(p_args)


def main():
  PushMetrics(omsa.FanStatus())
  PushMetrics(omsa.ChassisStatus())
  PushMetrics(omsa.TemperatureStatus())
  PushMetrics([omsa.ChassisBatteryStatus()])
  PushMetrics([omsa.RAIDBatteryStatus()])
  PushMetrics(omsa.MemoryStatus())
  PushMetrics(omsa.PowerSupplyStatus())
  PushMetrics(omsa.CpuStatus())
  PushMetrics(omsa.Summary())
  PushMetrics([omsa.LastRunTime()])
  PushMetrics(omsa.PhysicalDiskStatus())
  PushMetrics(omsa.VirtualDiskStatus())


if __name__ == '__main__':
  main()
