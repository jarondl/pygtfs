#!/usr/bin/python
# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/glinux_updater_monarch.py#1 $
"""gLinux-updater push-metric script to export updater status to Monarch."""

import os
import subprocess

STATUS_FILES = {'lastrun': '/var/lib/goobuntu/lastrun', 'lastsuccess':
                '/var/lib/goobuntu/lastsuccess'}
PUSH_METRIC_BIN = '/usr/local/bin/push_metrics'


def GetMtimeFromFile(fname):
  if os.path.exists(fname):
    return os.stat(fname).st_mtime  # epoch time in seconds.
  return 0  # fname doesn't exist.


def PushMetrics():
  if os.path.exists(PUSH_METRIC_BIN):
    for key, value in STATUS_FILES.iteritems():
      mtime = GetMtimeFromFile(value)
      if  mtime != 0:
        subprocess.call([PUSH_METRIC_BIN, '--metric', 'timestamp_in_secs',
                         '--source', 'glinux_updater', '--value', str(mtime),
                         '--label', key])


def main():
  PushMetrics()


if __name__ == '__main__':
  main()
