#!/bin/bash
# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/postfix.sh#1 $
# Basic checks for Postfix being alive and healthy.

# TODO(emcclung): Revist exporting relayhost if/when collectd supports string
# metrics.

function processHealthy () {
  # Check the Postfix master process is running. We assign a non-zero value to
  # indicate a problem.

  POSTFIXSPOOL="/var/spool/postfix"
  POSTFIXLOCK="${POSTFIXSPOOL}/pid/master.pid"

  if [[ -e ${POSTFIXLOCK} ]]; then
    MASTERPID=$(sed 's/\s//g' ${POSTFIXLOCK})
    # PID was not found.
    if ! ( ps --noheaders -C master | grep -q "${MASTERPID}" ); then
      /usr/local/bin/push_metrics --metric="postfix" --source="postfix" \
      --label="daemon" --value=1 --logtostderr
      exit 0
    fi
  else
    # Lock file was not found.
    /usr/local/bin/push_metrics --metric="postfix" --source="postfix" \
    --label="lockfile" --value=1 --logtostderr
    exit 0
  fi
}

function postfixQueue () {
  # Check for a non-zero Postfix queue length.
  if ! ( /usr/bin/mailq | grep -q 'Mail queue is empty' ); then
    # postfix is OK as it's up - the queue backup might be due to external
    # issues, so we'll monitor the postfix-queue-length variable instead.
    /usr/local/bin/push_metrics --metric="postfix" --source="postfix" \
    --label="postfix-queue" --value=1 --logtostderr

    # Export the mail queue length.
    mailinq=$(mailq | tail -n 1 | cut -d' ' -f5)
    /usr/local/bin/push_metrics --metric="postfix" --source="postfix" \
    --label="postfix-queue-length" --value="${mailinq}"
    exit 0
  fi
}

function isHealthy() {
  labels="daemon lockfile postfix-queue postfix-queue-length"
  for label in $labels; do
    /usr/local/bin/push_metrics --metric="postfix" --source="postfix" \
    --label="${label}" --value=0
  done
  exit 0
}

function main () {
  processHealthy
  postfixQueue
  isHealthy
}

main
