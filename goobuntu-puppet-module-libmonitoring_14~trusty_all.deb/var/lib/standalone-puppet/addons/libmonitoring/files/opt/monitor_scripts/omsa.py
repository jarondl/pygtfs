#!/usr/bin/python
# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/omsa.py#3 $

"""A Collectd plugin for reporting Hardware status on DELL class Servers."""

import os
import re
import subprocess
import time


# TODO(bassal): refactor these paths so that this could be more generic.
SERVICE_PATH = '/opt/dell/srvadmin/sbin/srvadmin-services.sh status'
LINUX_PATH = '/opt/dell/srvadmin/bin/'
LOCK_FILE = '/var/lock/hwreport.lock'
TEMP_DELTA = 5


class UnableToExecuteCommand(Exception):
  """Unable to run command."""


def ValidControllers():
  """Finds the number of valid disk controllers.

  Returns:
   A list containing controllers found e.g [0, 1]
  """
  controller_data = ParseOmreport('omreport storage controller')
  valid_controllers = ParseData('ID', controller_data)
  return valid_controllers


def FanStatus():
  """Fan status.


  Runs omreport command
  Runs regex to grab fan data from omreport
  Adds results to my_varz

  Process is repeated for each component with variations to the search strings
  and output layout.

  Returns:
   A list of dictionary containing fan speed and fan count metrics

  """
  omsa_fan = []
  fan_data = ParseOmreport('omreport chassis fans')
  if 'No fan probes' in fan_data.decode('utf-8'):
    return None
  fan_name = ParseData('Probe Name', fan_data)
  fan_rpm = ParseData('Reading', fan_data, pattern=r'\nReading\s+:\s+(.*?)\s')

  for rpm in range(len(fan_rpm)):
    m_fan_speed = {
        'plugin_instance': 'fan',
        'type_instance': 'fan_%s' % (rpm + 1),
        'type': 'rpm',
        'value': fan_rpm[rpm],
    }
    omsa_fan.append(m_fan_speed)

  m_fan_count = {
      'plugin_instance': 'fan',
      'type': 'count',
      'value': len(fan_name),
  }
  omsa_fan.append(m_fan_count)

  return omsa_fan


def ChassisStatus():
  """Chassis Intrusion Status.

  Runs regex to capture data from omreport

  Returns:
   A list of dictionary containing chassis intrusion metrics

  """
  chassis_status = []
  chassis_data = ParseOmreport('omreport chassis intrusion')
  chassis_state = ParseData('State', chassis_data)
  count = 0

  for _ in chassis_state:
    intrusion = {
        'type_instance': 'index_%s' % count,
        'type': 'chassis_intrusion',
        'value': 0,
    }
    chassis_status.append(intrusion)
    count += 1

    return chassis_status


def TemperatureStatus():
  """System Board Temperature Status.

  Runs regex to capture data from omreport

  Returns:
   A list of dictionary containing chassis temperature metrics

  """
  temperature = []
  temp_data = ParseOmreport('omreport chassis temps')

  if 'No temperature probes' in temp_data.decode('utf-8'):
    return None
  reading = ParseData(
      'Reading', temp_data, pattern=r'\nReading\s+:\s+(.*?)\s')
  status = ParseData('Status', temp_data)
  temp = {
      'type': 'temperature',
      'value': reading[0],
  }
  temperature.append(temp)

  if status[0].lower() == 'ok':
    temp_status = '0'
  else:
    temp_status = '1'

  temp_status = {
      'type': 'temperature_status',
      'value': temp_status,
  }
  temperature.append(temp_status)

  return temperature


def ChassisBatteryStatus():
  """CMOS Battery Status.

  Runs regex to capture data from omreport

  Returns:
   A dictinary containing chassis battery metrics

  """
  chassis_battery_data = ParseOmreport('omreport chassis batteries')
  if 'No battery probes' in chassis_battery_data.decode('utf-8'):
    return None
  status = ParseData('Status', chassis_battery_data)
  if status[0].lower() == 'ok':
    chassis_battery_status = 0
  else:
    chassis_battery_status = 1

  bstatus = {
      'plugin_instance': 'battery',
      'type': 'status',
      'value': chassis_battery_status,
  }

  return bstatus


def RAIDBatteryStatus():
  """RAID Battery Status.

  Runs regex to capture data from omreport

  Returns:
    A dictionary containing raid battery status.
      0 - battery is ok.
      1 - battery is degraded.
      2 - non-critical battery state.
      -1 - unknown state. We will still alert on unknown state here.

  """
  battery_data = ParseOmreport('omreport storage battery')

  if 'No battery probes' in battery_data.decode('utf-8'):
    return None
  status = ParseData('Status', battery_data)
  if status[0].lower() == 'ok':
    raid_battery_status = '0'
  elif status[0].lower() == 'degraded':
    raid_battery_status = '1'
  elif status[0].lower() == 'non-critical':
    raid_battery_status = '2'
  else:
    raid_battery_status = '-1'

  bstatus = {
      'plugin_instance': 'raid_battery',
      'type': 'status',
      'value': raid_battery_status,
  }
  return bstatus


def MemoryStatus():
  """Memory (RAM) Status.

  Runs regex to capture data from omreport

  Returns:
   A list of dictionary containing chassis memory metrics

  """
  memory_stats = []
  mem_data = ParseOmreport('omreport chassis memory')
  mem_size = ParseData('Size', mem_data, pattern=r'Size\s+:\s+(.*?)\n')
  mem_slot = ParseData('Connector Name', mem_data)
  mem_status = ParseData('Status', mem_data)

  dimm_status = []
  mem_count = 0
  slot_count = 0

  for ram in mem_size:
    size_label = mem_size[mem_count].replace(' ', '')
    slot_label = mem_slot[mem_count].replace(' ', '')
    if ram != ' ':
      slot_count += 1

    if mem_status[mem_count].lower() == 'ok':
      dimm_status = 0
    elif mem_status[mem_count].lower() == 'unknown':
      dimm_status = 0
    else:
      dimm_status = 1
    mem_count += 1
    mstats = {
        'plugin_instance': 'memory',
        'type': 'status',
        'type_instance': slot_label,
        'value': dimm_status,
    }
    memory_stats.append(mstats)
    size_lbl = size_label.replace('MB', '')
    if size_lbl and 'Index:' not in size_lbl:
      size_stats = {
          'plugin_instance': 'memory',
          'type': 'size_mb',
          'type_instance': slot_label,
          'value': int(size_lbl),
      }
      memory_stats.append(size_stats)

  count_stats = {
      'plugin_instance': 'memory',
      'type': 'count',
      'value': slot_count,
  }
  memory_stats.append(count_stats)

  return memory_stats


def PowerSupplyStatus():
  """Power Supply Status.

  Runs regex to capture data from omreport

  Returns:
    list of dictionary containing Power Supply status.

  """
  pwr_data = ParseOmreport('omreport chassis pwrsupplies')
  pwr = re.findall(r'PS[ \t]*\d', pwr_data.decode('utf-8'))
  pwr_status = ParseData('Status', pwr_data)
  return GetStatus('pwr_supply', pwr, pwr_status)


def CpuStatus():
  """CPU Status.

  Runs regex to capture data from omreport

  Returns:
    list of dictionary containing CPU status.

  """
  cpu_data = ParseOmreport('omreport chassis processors')
  processor = ParseData('Connector Name', cpu_data)
  cpu_status = ParseData('Status', cpu_data)
  return GetStatus('cpu', processor, cpu_status)


def Summary():
  """Summary info on chassis components.

  Runs & captures chassis summary status

  Returns:
   A list of dictionary containing chassis summary metrics

  """
  summary = []
  data = ParseOmreport('omreport chassis')
  data = data.decode('utf-8').replace(' ', '').splitlines()

  for item in data:
    if ':' not in item or 'SEVERITY' in item:
      continue
    key, component = item.split(':', 1)
    if key == 'Ok':
      status = 0
    else:
      status = 1
    stats = {
        'plugin_instance': 'chassis',
        'type': 'summary',
        'type_instance': component,
        'value': status,
    }
    summary.append(stats)

  return summary


def ParseOmreport(command):
  """Parses omreport command.

  Args:
    command: an omreport command
    e.g: omreport chassis temps.

  Raises:
   OSError: if dell openmanage is not installed or running.

  Returns:
      data from output of omreport.
  """
  try:
    if os.name == 'posix':  # Check if linux, add path to bin
      process = subprocess.Popen(
          (LINUX_PATH + command).split(),
          bufsize=-1,
          stdout=subprocess.PIPE,
          stderr=subprocess.PIPE)
    else:
      process = subprocess.Popen(
          command, bufsize=-1, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    data = process.stdout.read()
    process.stdout.close()
  except OSError as e:
    raise UnableToExecuteCommand("Error running '%s', %s" %
                                 (' '.join(command), e))
  return data


def GetStatus(component, keys, values):
  """Formats Status Results of components.

  Args:
    component: name of component
    keys: list of component names as reported by omreport command
    values: list of component statuses

  Returns:
    list of dictionary containing chassis component status.

  """
  res = []

  for item in range(len(keys)):
    if component != 'disk':
      label = '%s_%d' % (component, item + 1)  # Only Disk index starts at 1
    else:
      label = '%s_%s' % (component, item)
    if values[item].lower() == 'ok':
      status = 0
    elif values[item].lower() == 'unknown' and component != 'dimm':
      status = -1
    elif values[item].lower() == 'unknown' and component == 'dimm':
      status = 1
    else:
      status = 1

    stats = {
        'plugin_instance': component,
        'type': 'status',
        'type_instance': label,
        'value': status,
    }
    res.append(stats)

    return res


def VirtualDiskStatus():
  """Virtual Disk (RAID) Status.

  Runs regex to capture data from omreport

  Returns:
    A slice of virtual disks with their status
  """
  res = []
  controllers = ValidControllers()
  for controller in controllers:
    vdisk_data = ParseOmreport('omreport storage vdisk controller=%s' %
                               controller)
    vdisk = ParseData('Layout', vdisk_data.decode('utf-8'))
    vdisk_status = ParseData('Status', vdisk_data.decode('utf-8'))

    # reading vdisk and vdisk_status in the same for loop as size of both
    # arrays are the same.
    for vdisk_count in xrange(len(vdisk)):
      vdisk_label = 'vdisk%s_%s_%s' % (
          vdisk_count, controller,
          (vdisk[vdisk_count].lower().replace(' ', '_')))
      if vdisk_status[vdisk_count].lower() == 'ok':
        status = 0
      elif vdisk_status[vdisk_count].lower() == 'non-critical':
        status = 2
      else:
        status = 1
      stats = {
          'plugin_instance': 'virtual_disk_status',
          'type': 'status',
          'type_instance': vdisk_label,
          'value': status,
      }
      res.append(stats)
  return res


def PhysicalDiskStatus():
  """Physical Disk Status.

  Runs regex to capture data from omreport

  Returns:
    A slice of physical disks statuses.
  """
  res = []
  controllers = ValidControllers()

  for controller in controllers:
    pdisk_data = ParseOmreport('omreport storage pdisk controller=%s' %
                               int(controller)).decode('utf-8')
    pdisk_status = ParseData('Status', pdisk_data)
    pdisk_failure = ParseData('Failure Predicted', pdisk_data)

    # reading failure prediction and pdisk status from 2 same size arrays below.
    for pdisk_count in xrange(len(pdisk_status)):
      pdisk_label = 'disk%s_%s' % (controller, pdisk_count)
      pdisk_prediction_status = 0
      if pdisk_failure[pdisk_count].lower() != 'no':
        pdisk_prediction_status = 1
      pdisk_failure_stat = {
          'plugin_instance': 'disk_failure_prediction',
          'type': 'status',
          'type_instance': pdisk_label,
          'value': pdisk_prediction_status,
      }
      res.append(pdisk_failure_stat)
      if pdisk_status[pdisk_count].lower() == 'ok':
        pstatus = 0
      elif pdisk_status[pdisk_count].lower() == 'non-critical':
        pstatus = 2
      else:
        pstatus = 1
      pdisk_stat = {
          'plugin_instance': 'disk_status',
          'type': 'status',
          'type_instance': pdisk_label,
          'value': pstatus,
      }
      res.append(pdisk_stat)
  return res


def LastRunTime():
  """Checks last run Time.

  Returns:
    dictionary of last runtime metrics

  """
  stats = {
      'type': 'last_run_time',
      'value': int(time.time()),
  }
  return stats


def ParseData(keyword, keydata, pattern=None):
  """Parses data from regex search.

  Args:
    keyword: value data usually precedes a keyword.Using this as anchor in regex
    keydata: data to search
    pattern: regex pattern to match

  Given the following output:

     Probe List
     Index                     : 0
     Status                    : Ok
     Probe Name                : System Board FAN 1 RPM
     Reading                   : 7275 RPM
     Minimum Warning Threshold : [N/A]
     Maximum Warning Threshold : [N/A]
     Minimum Failure Threshold : 2025 RPM
     Maximum Failure Threshold : [N/A]

     Matches right hand side value  when used with left hand side string
     e.g  regex search on string 'Reading' Matches 7275

  Returns:
    list with match results.
  """
  if not pattern:
    pattern = r'\n%s\s+:\s+(.*?)[\r\n]' % keyword
  return re.findall(pattern, keydata.decode('utf-8'))
