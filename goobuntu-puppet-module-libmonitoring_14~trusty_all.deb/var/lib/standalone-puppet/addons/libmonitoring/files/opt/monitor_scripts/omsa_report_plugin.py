#!/usr/bin/python
# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/omsa_report_plugin.py#2 $

"""A Collectd plugin for reporting Hardware status on DELL class Servers."""

import collectd
import omsa


def DispatchValue(m_list):
  """Dispatches collectd metrics to be written out to output Collectd Plugins.

  Args:
    m_list: dictionary of metric fields.
  """
  if not m_list:
    return
  for m in m_list:
    v = collectd.Values(type=m.get('type'))
    v.plugin = 'omsa'
    v.type_instance = m.get('type_instance', '')
    v.plugin_instance = m.get('plugin_instance', '')
    v.dispatch(values=[m.get('value')])


def Read():
  """Collectd read callback function that would read values and dispatch."""
  DispatchValue(omsa.FanStatus())
  DispatchValue(omsa.ChassisStatus())
  DispatchValue(omsa.TemperatureStatus())
  DispatchValue([omsa.ChassisBatteryStatus()])
  DispatchValue([omsa.RAIDBatteryStatus()])
  DispatchValue(omsa.MemoryStatus())
  DispatchValue(omsa.PowerSupplyStatus())
  DispatchValue(omsa.CpuStatus())
  DispatchValue(omsa.Summary())
  DispatchValue([omsa.LastRunTime()])
  DispatchValue(omsa.PhysicalDiskStatus())
  DispatchValue(omsa.VirtualDiskStatus())


collectd.register_read(Read)
