#!/bin/bash
# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/last_mail_sent.sh#1 $

function getMail () {
  # EL/gLinux have maillog in different locations :<
  if [[ -e /var/log/maillog ]]; then
    MAILLOG="/var/log/maillog"
  else
    MAILLOG="/var/log/mail.log"
  fi

  RETVAL=$(grep 'to=<managedsystems-mail-monitoring+mail_test.*status=sent' $MAILLOG | tail -n 1 | cut -d '%' -f2)

  if ! [[ -z "${RETVAL}" ]]; then
    /usr/local/bin/push_metrics --metric="timestamp_in_secs" \
    --source="last_mail_sent" --value="${RETVAL}" --logtostderr
    exit 0
  else
    /usr/local/bin/push_metrics --metric="timestamp_in_secs" \
    --source="last_mail_sent" --value=0 --logtostderr
    exit 0
  fi
}

function preRec () {
  if ! [[ -x /usr/local/bin/push_metrics ]]; then
    echo "Could not find push_metrics bin. Exiting."
    exit 1
  fi
}

function main () {
  preRec
  getMail
}

main
