# $Id: //depot/google3/googledata/corp/puppet/services/libs/libmonitoring/files/opt/monitor_scripts/pending_mandatory_updates.ps1#1 $
$missing_apps = Get-SccmRequiredApplications -InstallableOnly
$missing_updates = Get-SccmRequiredUpdates -InstallableOnly
$pending_mandatory_updates = @()

$missing_apps | ForEach-Object {
  $name = ($_.Name -replace ' ','_')

  # Combine the software version and deployment revision
  $version = ($_.SoftwareVersion, "r$($_.Revision)") -join '_'
  $pending_mandatory_updates += "$($name):$($version)"
}

$missing_updates | ForEach-Object {
  $name = $_.ArticleID

  # CCM_SoftwareUpdates have no version, reuse ArticleID
  $pending_mandatory_updates += "KB$($name):$($name)"
}

$pending_mandatory_updates_count = "$(($pending_mandatory_updates | Measure-Object).Count)"
& push_metrics --metric count --source pending_mandatory_updates --value $pending_mandatory_updates_count --logtostderr

