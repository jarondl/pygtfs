#!/bin/bash

# $Id: $

FC_SYS_PATH=/sys/class/fc_host
if [[ -d ${FC_SYS_PATH} ]]; then
 cd ${FC_SYS_PATH}
 PORT_STATE_VARZ_STATE=""
 for i in host*
 do
   PORT_STATE_VARZ_STATE=$(cat "${FC_SYS_PATH}"/"${i}"/port_state)
   fc_host_status=$(echo "${PORT_STATE_VARZ_STATE}" | sed -e 's/Online/1/g' -e 's/[A-Z][A-Za-z]*/0/g')
   /usr/local/bin/push_metrics --metric fc_status --source fc_status --label "${i}" --value "${fc_host_status}" --logtostderr
 done
fi
