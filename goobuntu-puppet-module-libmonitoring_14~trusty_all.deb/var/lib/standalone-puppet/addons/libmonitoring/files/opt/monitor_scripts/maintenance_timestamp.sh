#!/bin/bash

# $Id: $

maintenance_timestamp_file='/opt/metrics_files/next_scheduled_maintenance'
if [[ ! -f "${maintenance_timestamp_file}" ]] ; then
  echo "file ${maintenance_timestamp_file} does not exist. Exiting..."
  exit 1
fi

maint_timestamp=$(cat "${maintenance_timestamp_file}"|cut -d' ' -f2)
if [[ -z ${maint_timestamp} ]] ; then
  echo "blank maintenance timestamp."
  exit 1
fi

if [[ ${maint_timestamp} == "NaN" ]] ; then
  echo "NaN. Exiting"
  exit 0
fi

/usr/local/bin/push_metrics --metric timestamp_in_secs --source maintenance_timestamp --value "${maint_timestamp}"

